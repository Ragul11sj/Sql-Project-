-- ============================================================
--  FOOD DELIVERY PLATFORM DATABASE
--  File: 00_run_all.sql
--  Description: Master script — runs everything in order
--  Usage: mysql -u root -p < 00_run_all.sql
-- ============================================================

SOURCE schema/01_schema.sql;
SOURCE data/02_seed_data.sql;
SOURCE views/03_views.sql;
SOURCE procedures/04_procedures.sql;
SOURCE triggers/05_triggers.sql;

SELECT '✅ Food Delivery DB setup complete!' AS Status;
